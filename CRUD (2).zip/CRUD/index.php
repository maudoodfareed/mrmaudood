<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> insert data in php</title>
</head>
<script type="text/javascript">
	function myFun(){
		var userEmail= document.getElementById('userEmail').value;
		var re= /^l1((f)||(s))[0-9]{2}((bscs)||(ascs))[0-9]{4}((@ucp.edu.pk))$/;
		if(userEmail.search(re)==-1){
			alert("plz enter ucp format");
			return false;
		}else{
		return true;
		}
	}
</script>
<body>
	//insert data
	<form action="insertData.php" method="POST" onsubmit="return myFun();">
		<input type="text" name="userName" placeholder="Enter your Name">
		<input type="text" name="userEmail" id="userEmail" placeholder="Enter yor Email">
		<input type="date" name="userdob" placeholder="Enter your DOB">
		<input type="submit" value=" Add my record">
	</form>
	<br>
	<br>

	<table border="1">
		<tr>
			<th>Name</th>
			<th>Email</th>
			<th>Date</th>
			<th>operations</th>
		</tr>
		<?php
		$conn= new mysqli("localhost","root","","wad");

		$query="select * from user_info";
		$result = $conn->query($query);
		while ($row=$result->fetch_assoc()) {
			echo '<tr>';
			echo '<td>'.$row['name'].'</td>';
			echo '<td>'.$row['email'].'</td>';
			echo '<td>'.$row['dob'].'</td>';
			//update &delete
			echo '<td><a href="edit.php?id='.$row['id'].'">Edit </a> / <a 
			href="delete.php?id='.$row['id'].'">delete</a></td>';
			echo '</tr>';

		}
		?>
	</table>

</body>
</html>