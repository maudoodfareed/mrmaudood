<?php  

	$id=$_GET['id'];

	//database connection
	$conn= new mysqli("localhost","root","","wad");
	$query="delete from user_info where id=".$id;
	

	if($conn->query($query)==1){
		header("location:index.php");
	}else{
		echo $conn->error;
	}

?>