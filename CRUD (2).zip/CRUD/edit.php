<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> edit data in php</title>
</head>
<script type="text/javascript">
	function myFun(){
		var userEmail= document.getElementById('userEmail').value;
		var re= /^l1((f)||(s))[0-9]{2}((bscs)||(ascs))[0-9]{4}((@ucp.edu.pk))$/;
		if(userEmail.search(re)==-1){
			alert("plz enter ucp format");
			return false;
		}else{
		return true;
		}
	}
</script>

<?php
		$id=$_GET['id'];
		$conn= new mysqli("localhost","root","","wad");

		$query="select * from user_info where id=".$id;
		$result = $conn->query($query);
		$row=$result->fetch_assoc()
		
?>
<body> 
	//insert data
	<form action="update.php" method="POST" onsubmit="return myFun();">
		<input type="text" name="userName" placeholder="Enter your Name" value="<?php echo $row['name']; ?>">
		<input type="text" name="userEmail" id="userEmail" placeholder="Enter yor Email" value="<?php echo $row['email']; ?>"> 
		<input type="hidden" name="id" value="<?php echo $id ?>">

		<input type="submit" value=" Add my record">
	</form>
	<br>
	<br>	
</body>
</html>