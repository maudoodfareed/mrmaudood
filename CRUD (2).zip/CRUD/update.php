<?php  

	$name=$_POST['userName'];
	$email=$_POST['userEmail'];
	$id=$_POST['id'];

	//database connection
	$conn= new mysqli("localhost","root","","wad");
	$query="update user_info set name='" .$name."' , email='" .$email."' where id=".$id;
	//echo $querry;

	if($conn->query($query)==1){
		header("location:index.php");
	}else{
		echo $conn->error;
	}

?>