 <?php  

	$name=$_POST['userName'];
	$email=$_POST['userEmail'];
	$dob=$_POST['userdob'];

	//database connection
	$conn= new mysqli("localhost","root","","wad");
	$query="insert into user_info(name,email,dob) values('".$name."','".$email."','".$dob."')";
	if($conn->query($query)==1){
		echo "Data inserted";
	}else{
		echo $conn->error;
	}

?>